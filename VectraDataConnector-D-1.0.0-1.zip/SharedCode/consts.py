"""This file contains all constants."""

LOGS_STARTS_WITH = "Vectra : "
ACCOUNT_DETECTION_NAME = "Account Detection"
AUDITS_NAME = "Audits"
ENTITY_SCORING_NAME = "Entity Scoring"
DEFAULT_LOG_LEVEL = 20
OAUTH2_ENDPOINT = "/oauth2/token"
API_TIMEOUT = 180
SENTINEL_ACCEPTABLE_CODES = list(range(200, 300))
